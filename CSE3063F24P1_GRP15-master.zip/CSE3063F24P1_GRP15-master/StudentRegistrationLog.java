
import java.util.ArrayList;

public class StudentRegistrationLog {
	private ArrayList<Course> finishedCourses;
	private ArrayList<Course> currentCourses;
	private ArrayList<Course> demandedCourses;
	private ArrayList<CourseSection> demandCoursesSections;
	private ArrayList<CourseSection> currentCoursesSections;

	public StudentRegistrationLog(ArrayList<Course> finishedCourses, ArrayList<Course> currentCourses, ArrayList<Course> demandedCourses) {
		this.finishedCourses = finishedCourses;
		this.currentCourses = currentCourses;
		this.demandedCourses = demandedCourses;
	}

	public ArrayList<Course> getCurrentCourses() {
		return currentCourses;
	}

	public ArrayList<Course> getDemandedCourses() {
		return demandedCourses;
	}

	public ArrayList<Course> getFinishedCourses() {
		return finishedCourses;
	}
	public void fromDemandedCoursesToCurrentCourses(Course course) {
		currentCourses.add(course);
		demandedCourses.remove(course);

	}
	public void setDemandedCourses(ArrayList<Course> courses,ArrayList<CourseSection> sections){
		this.demandedCourses=courses;
		this.demandCoursesSections=sections;
	}
	public void setCurrentCourses(ArrayList<Course> courses,ArrayList<CourseSection> sections){
		this.currentCourses=courses;
		this.currentCoursesSections=sections;
	}
	public ArrayList<CourseSection> getDemandCoursesSections(){
		return demandCoursesSections;
	}
	public ArrayList<CourseSection> getCurrentCoursesSections(){
		return currentCoursesSections;
	}
	public void setDemandedCoursesSections(ArrayList<CourseSection> sections){
		this.demandCoursesSections=sections;
	}
	public void setCurrentCoursesSections(ArrayList<CourseSection> sections){
		this.currentCoursesSections=sections;
	}

}
