
import static org.junit.Assert.*;

import org.junit.Test;

public class StudentTest {
    @Test
    public void StudentIDTest(){
        Student student = new Student(2, "Ahmet Yılmaz", 's', null);
        assertEquals(2,student.getID());
    }

    @Test
    public void StudentNameTest(){
        Student student = new Student(2, "Ahmet Yılmaz", 's', null);
        assertEquals("Ahmet Yılmaz",student.getNameSurname());
    }
}
