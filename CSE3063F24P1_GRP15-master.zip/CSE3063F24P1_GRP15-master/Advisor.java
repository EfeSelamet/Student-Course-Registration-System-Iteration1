import java.util.ArrayList;

public class Advisor extends Person{
    private ArrayList<String> studentUsernames; 

    public Advisor(int ID, String nameSurname, char type, ArrayList<String> studentUsernames){
        super(ID,nameSurname,type);
        this.studentUsernames = studentUsernames;
    }

    public ArrayList<String> getStudents(){
        return studentUsernames;
    }
}
