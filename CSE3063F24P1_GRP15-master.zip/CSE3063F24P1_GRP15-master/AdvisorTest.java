import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Test;

public class AdvisorTest {
    @Test
    public void AdvisorTest(){
        ArrayList<String> studentList = new ArrayList<>(Arrays.asList("user1","user2","user3","user7", "user8"));
        Advisor advisor = new Advisor(101,"Serap Korkmaz",'a', studentList);
        assertEquals(101, advisor.getID());
    }
}
