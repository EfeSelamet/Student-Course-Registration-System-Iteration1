import java.util.ArrayList;
import java.util.Scanner;
public class UserInterface {
    
    // Singleton variables
    private static LoginSystem loginSystem;
    private static RegistrationSystem registrationSystem;
    public static void main(String args[])
    {
        loginSystem = new LoginSystem();
        registrationSystem = new RegistrationSystem();
        loginScreen();
    }

    public static RegistrationSystem getRegistrationSystem()
    {
        return registrationSystem;
    }

    public static void loginScreen()
    {   
        String username = "";
        String password = "";
        do {
        
        Scanner input = new Scanner(System.in);
        // take username input from user if username is empty or have whitespaces throw exception
        try{
        System.out.println("Please enter username:");
        
        username = input.nextLine();

        if (username.isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty.");
        }

        for (int i = 0; i < username.length(); i++) {
             if (username.charAt(i) == ' ')
                throw new IllegalArgumentException("Username cannot have white spaces.");
        }
        }

        catch(IllegalArgumentException e)
        {
            System.out.println("Error: " + e.getMessage());
        }

        // take username input from user if username is empty or have whitespaces throw exception
        try{
            System.out.println("Please enter password:");
            
            password = input.nextLine();
    
            if (password.isEmpty()) {
                throw new IllegalArgumentException("Password cannot be empty.");
            }
            }
    
            catch(IllegalArgumentException e)
            {
                System.out.println("Error: " + e.getMessage());
            }
        } while (!UserInterface.loginSystem.login(username, password));
        if(UserInterface.loginSystem.getCurrentUser().getType() == 's')
        {
            courseRegistrationScreen();
        }
        else
        {
            advisorStudentScreen();
        }
    }
    public static void courseRegistrationScreen()
    {
        ArrayList<CourseSection> selectedCourseSections = new ArrayList<>();
        ArrayList<Course> selectedCourses = new ArrayList<>();
        ArrayList<Course> availableCourses = UserInterface.registrationSystem.getAvailableCourses((Student)UserInterface.loginSystem.getCurrentUser());
        while(true){
        System.out.println("Usage");
        System.out.println("----------------------------");
        System.out.println("In order to add a course to selected courses list type : \"add 'course index in available courses list'\"");
        System.out.println("\texample: add 3");
        System.out.println("In order to remove a course from selected courses list type : \"remove 'course index in selected courses list'\"");
        System.out.println("\texample: remove 2");
        System.out.println("In order to confirm your courses type \"confirm\"\n");
        
        System.out.println("Available Courses");
        System.out.println("----------------------------");
        int[] courseSectionNumbers = new int[availableCourses.size()];
        
        int k=1;
        for (int i = 0; i < courseSectionNumbers.length; i++) {
            ArrayList<CourseSection> sections = availableCourses.get(i).getSections();
            courseSectionNumbers[i] = sections.size();
            Course course = availableCourses.get(i);
            String name = course.getCourseName();
            String code = course.getCourseCode();

            for (int j = 0; j < sections.size(); j++) {
                CourseSection section = sections.get(j);
                int sectionNumber = section.getSectionNumber();
                String day = section.getDay();
                String hour = section.getHour();
                System.out.printf("%d. %s.%d %s\n\t%s\n\t%s\n\n", k++, code, sectionNumber, name, day, hour);
            }
        }

        System.out.println("\nSelected Courses");
        System.out.println("----------------------------");
        
        k =1;
        for (int i = 0; i < selectedCourseSections.size(); i++) {
            Course course = selectedCourses.get(i);
            String name = course.getCourseName();
            String code = course.getCourseCode();
            CourseSection section = selectedCourseSections.get(i);
            int sectionNumber = section.getSectionNumber();
            String day = section.getDay();
            String hour = section.getHour();
            System.out.printf("%d. %s.%d %s\n\t%s\n\t%s\n\n", k++, code, sectionNumber, name, day, hour);
        }

        Scanner scanner = new Scanner(System.in);
        String input[] = scanner.nextLine().split(" ");

        if(input.length == 1 && input[0].equals("confirm"))
        {
            UserInterface.registrationSystem.demandCourses(selectedCourses, (Student)UserInterface.loginSystem.getCurrentUser(), selectedCourseSections);
            UserInterface.loginSystem.logOut();
            loginScreen();
        }

        else if(input.length == 2 )
        {
            int courseIndex;
            try 
            {
                courseIndex = Integer.parseInt(input[1]);    
            } catch (NumberFormatException e) {
                System.out.println("Course index must be an integer");
                continue;
            }

            if(input[0].equals("add"))
            {
                boolean found = false;
                for (int i = 0; i < courseSectionNumbers.length; i++) {
                    if(courseIndex <= courseSectionNumbers[i])
                    {
                        Course selectedCourse = availableCourses.get(i);
                        int selectedSection = courseIndex - 1;
                        selectedCourseSections.add((selectedCourse.getSections().get(selectedSection)));
                        selectedCourses.add(selectedCourse);
                        availableCourses.remove(selectedCourse);
                        found= true;
                        break;
                    }
                    else
                    {
                        courseIndex -= courseSectionNumbers[i];
                    }

                }
                if(!found)
                    System.out.println("Invalid course index.");
                continue;
            }
            else if(input[0].equals("remove"))
            {   
                courseIndex -= 1;
                if (courseIndex >= selectedCourseSections.size())
                {
                    System.out.println("Invalid course index.");
                    continue;
                }
                Course course = selectedCourses.get(courseIndex);
                selectedCourses.remove(course);
                selectedCourseSections.remove(courseIndex);
                availableCourses.add(course);

            }
            else
            {
                System.out.println("Invalid input.");
                continue;
            }
        }

        else
        {
            System.out.println("Invalid input.");
            continue;
        }
    }
    }
    public static void advisorStudentScreen()
    {
        ArrayList<Student> students = new ArrayList<>();
        Advisor advisor = (Advisor)UserInterface.loginSystem.getCurrentUser();
        ArrayList<String> studentUsernames = advisor.getStudents();
        for (String username : studentUsernames) {
           students.add(UserInterface.registrationSystem.createStudent(username));
        }
        while (true) {
        System.out.println("Type the corresponding number next to student names to select a student.");
        System.out.println("----------------------------");
        for (int i = 0; i < students.size(); i++) {

            System.out.printf("%d.%s StudentNumber: %d\n", i+1, students.get(i).getNameSurname(), students.get(i).getID());
        }

        Scanner scanner = new Scanner(System.in);
        int index;
        try {
            index = scanner.nextInt();
        } catch (Exception e) {
            System.out.println("Invalid input.");
            continue;
        }
        if (index < 1 || index > students.size()) {
            System.out.println("Invalid input.");
            continue;
        }
        index-=1;
        advisorVerificationScreen(students.get(index));
        break;
    }
    }
    public static void advisorVerificationScreen(Student student)
    {
        StudentRegistrationLog regLog = student.getStudentRegistrationLog();
        ArrayList<Course> demandedCourses = regLog.getDemandedCourses();
        ArrayList<CourseSection> demandedCourseSections = regLog.getDemandCoursesSections();
        ArrayList<Course> verifiedCourses = new ArrayList<Course>();
        ArrayList<CourseSection> verifiedCourseSections = new ArrayList<CourseSection>();
        ArrayList<Course> rejectedCourses = new ArrayList<Course>();
        ArrayList<CourseSection> rejectedCourseSections = new ArrayList<CourseSection>();
        
        while(true)
        {
        System.out.println("Usage");
        System.out.println("----------------------------");
        System.out.println("In order to verify a course chosen by the student type : \"verify 'course index'\"");
        System.out.println("\texample: verify 3");
        System.out.println("In order to remove a course from selected courses list type : \"reject 'course index'\"");
        System.out.println("\texample: reject 2");
        System.out.println("In order to confirm your choices type \"confirm\"\n");
        System.out.println("----------------------------\n");

        System.out.println("Courses chosen by the student:");
        int k =1;
        for (int i = 0; i < demandedCourseSections.size(); i++) {
            Course course = demandedCourses.get(i);
            String name = course.getCourseName();
            String code = course.getCourseCode();
            CourseSection section = demandedCourseSections.get(i);
            int sectionNumber = section.getSectionNumber();
            String day = section.getDay();
            String hour = section.getHour();
            String isVerified = "";
            if(verifiedCourses.contains(course))
                isVerified = "(VERIFED)";
            else if(rejectedCourses.contains(course))
                isVerified = "(REJECTED)";
            System.out.printf("%d. %s.%d %s  %s\n  %s\n\t%s\n\n", k++, code, sectionNumber, name, isVerified, day, hour);
        }

        Scanner scanner = new Scanner(System.in);
        String input[] = scanner.nextLine().split(" ");

        if(input.length == 1 && input[0].equals("confirm"))
        {
            registrationSystem.approveCourses(student, verifiedCourses, verifiedCourseSections);
            registrationSystem.rejectCourses(student, rejectedCourses);
            loginSystem.logOut();
            loginScreen();
            break;
        }

        else if(input.length == 2 )
        {
            int courseIndex;
            try 
            {
                courseIndex = Integer.parseInt(input[1]) - 1;    
            } catch (NumberFormatException e) {
                System.out.println("Course index must be an integer");
                continue;
            }

            if (courseIndex >= demandedCourses.size() && courseIndex < 0) 
            {
                System.out.println("Invalid index.");
                continue;    
            }
            if(input[0].equals("verify"))
            {   
                if(!verifiedCourses.contains(demandedCourses.get(courseIndex)))
                {
                    verifiedCourses.add(demandedCourses.get(courseIndex));
                    verifiedCourseSections.add(demandedCourseSections.get(courseIndex));
                }
                if(rejectedCourses.contains(demandedCourses.get(courseIndex)))
                {
                    rejectedCourses.remove(demandedCourses.get(courseIndex));
                    rejectedCourseSections.remove(demandedCourseSections.get(courseIndex));
                }
            }
            else if(input[0].equals("reject"))
            {   
                if(!rejectedCourses.contains(demandedCourses.get(courseIndex)))
                {
                    rejectedCourses.add(demandedCourses.get(courseIndex));
                    rejectedCourseSections.add(demandedCourseSections.get(courseIndex));
                }
                if(verifiedCourses.contains(demandedCourses.get(courseIndex)))
                {
                    verifiedCourses.remove(demandedCourses.get(courseIndex));
                    verifiedCourseSections.remove(demandedCourseSections.get(courseIndex));
                }
            }
            else
            {
                System.out.println("Invalid input.");
                continue;
            }
        }

        else
        {
            System.out.println("Invalid input.");
            continue;
        }}
    }
}
