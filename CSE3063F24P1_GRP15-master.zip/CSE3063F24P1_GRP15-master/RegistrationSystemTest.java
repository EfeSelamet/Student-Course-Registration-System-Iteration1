import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;


public class RegistrationSystemTest {
    @Test
    public void getAvailableCourseTester(){
        RegistrationSystem registrationSystemAvailableCourseTest = new RegistrationSystem();
        Student student = registrationSystemAvailableCourseTest.createStudent("Ali Yılmaz");
        assertEquals("Computer Programming 2",registrationSystemAvailableCourseTest.getAvailableCourses(student).get(0).getCourseName());
    }

    @Test
    public void CreateStudentTest(){
        RegistrationSystem regSys = new RegistrationSystem();
        assertEquals(1,regSys.createStudent("Ali Yılmaz").getID());
    }

    @Test
    public void createAdvisorTest(){
        RegistrationSystem regSys = new RegistrationSystem();
        assertEquals(101,regSys.createAdvisor("Serap Korkmaz").getID());
    }

    @Test
    public void CreateCoursesTest(){
        RegistrationSystem regSys = new RegistrationSystem();
        ArrayList<String> courseString = new ArrayList<String>();
        courseString.add("CSE1242.1");
        courseString.add("CSE1242.2");
        assertEquals("Computer Programming 2",regSys.createCourses(courseString).get(0).getCourseName());
    }


}
/*demandCourses
approveCourses
rejectCourses
login*/