abstract class Person {
    private int ID;
    private String nameSurname;
    private char type;

    public Person(){
        
    }

    public Person(int ID, String nameSurname, char type){
        this.ID = ID;
        this.nameSurname = nameSurname;
        this.type = type;
    }

    public int getID(){
        return ID;
    }
    public String getNameSurname(){
        return nameSurname;
    }
    public char getType(){
        return type;
    }
}
