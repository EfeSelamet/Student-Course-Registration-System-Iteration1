

public class Student extends Person{
   
    StudentRegistrationLog studentRegistrationLog;

    public Student(int ID, String nameSurname, char type,StudentRegistrationLog studentRegistrationLog){
        super(ID,nameSurname,type);
        
        this.studentRegistrationLog = studentRegistrationLog;
    }

    
    public StudentRegistrationLog getStudentRegistrationLog(){
        return studentRegistrationLog;
    }

}
