import java.util.ArrayList;

public class Course{
    private String courseName;
    private ArrayList<CourseSection> sections;
    private ArrayList<Course> prerequisites;
    private String courseCode;

    public Course(ArrayList<CourseSection> sections,ArrayList<Course> prerequisites, String courseCode){
        this.sections = sections;
        this.prerequisites = prerequisites;
        this.courseCode = courseCode;
    }

    public String getCourseName(){
        return courseName;
    }
    public void setCourseName(String courseName){
        this.courseName = courseName;
    }

    public ArrayList<CourseSection> getSections(){
        return sections;
    }

    public ArrayList<Course> getPrerequisites(){
        return prerequisites;
    }

    public String getCourseCode(){
        return courseCode;
    }
    public int getYear(){
        int year = Integer.parseInt(courseCode.substring(3,4));
        return year;
    }
}
