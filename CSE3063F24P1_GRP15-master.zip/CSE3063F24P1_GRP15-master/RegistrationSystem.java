import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.ArrayList;


public class RegistrationSystem {


    ArrayList<Course> courses = new ArrayList<>();
    
    @SuppressWarnings("unchecked")
    public RegistrationSystem() {
        JSONParser parser = new JSONParser();

        try{
            FileReader reader = new FileReader("JSONfiles/courses.json");
            JSONArray coursesArray = (JSONArray) parser.parse(reader);
            

            
            
            for(Object obj:coursesArray){
                JSONObject coursesObject = (JSONObject)obj;
                
                
                ArrayList<String> Days;
                Days = (ArrayList<String>) coursesObject.get("Day");
                ArrayList<String> Hours ;
                Hours = (ArrayList<String>) coursesObject.get("Hour");
                ArrayList<String> prerequisites ;
                prerequisites = (ArrayList<String>) coursesObject.get("CoursePrerequisites");
                		
                ArrayList<CourseSection> courseSectionsList = new ArrayList<>();
                for(int j = 0;j<Days.size();j++) {
                	courseSectionsList.add(new CourseSection(Days.get(j),Hours.get(j),j+1));
                }
                
                
               ArrayList<Course> prerequisitesCourseObject = new ArrayList<>();
                if(prerequisites == null) {
                	prerequisites = new ArrayList<>();
                }
                for(int i=0;i<prerequisites.size();i++) {
                	for(int j = 0;j<courses.size();j++) {
                		if(prerequisites.get(i).equals(courses.get(j).getCourseCode())) {
                			prerequisitesCourseObject.add(courses.get(j));
                		}
                	}
                }
                
                Course newCourse = new Course(courseSectionsList,prerequisitesCourseObject,(String)coursesObject.get("CourseCode"));
                newCourse.setCourseName((String)coursesObject.get("CourseName"));
                courses.add(newCourse);
                
            }
            
        }
        catch (FileNotFoundException e){
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

    }
    

    private boolean checkPrerequisite(Course course,Student student){
        @SuppressWarnings("unchecked")
        ArrayList<Course> finishedCourses = (ArrayList<Course>) student.getStudentRegistrationLog().getFinishedCourses();
        for(Course c: course.getPrerequisites()){
            
            if(!finishedCourses.contains(c)){
                return false;
            }
            




        }

        return true;

    }

    //Get available courses based on the student's finished courses
    public ArrayList<Course> getAvailableCourses(Student student){
       ArrayList<Course> availableCourses = new ArrayList<Course>();
       ArrayList<Course> finishedCourses = student.getStudentRegistrationLog().getFinishedCourses();
        for(Course c: courses){
            if(checkPrerequisite(c,student) && !finishedCourses.contains(c)){
                availableCourses.add(c);
            }


        }
        return availableCourses;

    }
    @SuppressWarnings("unchecked")

    //Append the given json file's given column with the new given  string list
    private void changeDataString(String opt,String file,String identifier,String columnToBeChanged, ArrayList<String> newList){
        JSONParser parser = new JSONParser();
        FileReader reader = null;
        try {
            reader = new FileReader(file);
            JSONArray array = (JSONArray) parser.parse(reader);

            for(Object obj:array){

                JSONObject jsonObj = (JSONObject) obj;
                if(((String)jsonObj.get(opt)).equals(identifier)){
                    JSONArray existingArray = (JSONArray) jsonObj.get(columnToBeChanged);
                    for(String s : newList){
                        existingArray.add(s);
                    }


                    jsonObj.put(columnToBeChanged,existingArray);

                }


            }
            FileWriter writer = new FileWriter(file);
            writer.write(array.toJSONString());
            writer.flush();
            writer.close();


        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

    }
    //Append the given json file's given column with the new given  integer list
    private void changeDataInteger(String opt,String file,String identifier,String columnToBeChanged,ArrayList<Integer> newList){
        JSONParser parser = new JSONParser();
        FileReader reader = null;
        try {
            reader = new FileReader(file);
            JSONArray array = (JSONArray) parser.parse(reader);

            for(Object obj:array){

                JSONObject jsonObj = (JSONObject) obj;
                if(((String)jsonObj.get(opt)).equals(identifier)){
                    JSONArray existingArray = (JSONArray) jsonObj.get(columnToBeChanged);
                    for(Integer s : newList){
                        existingArray.add(s);
                    }


                    jsonObj.put(columnToBeChanged,existingArray);

                }


            }
            FileWriter writer = new FileWriter(file);
            writer.write(array.toJSONString());
            writer.flush();
            writer.close();


        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

    }

    //overWrite the given json file's given column with the new given  string list
    private void overWriteDataString(String opt,String file,String identifier,String columnToBeChanged,ArrayList<String> newList){
        JSONParser parser = new JSONParser();
        FileReader reader = null;
        try {
            reader = new FileReader(file);
            JSONArray array = (JSONArray) parser.parse(reader);

            for(Object obj:array){

                JSONObject jsonObj = (JSONObject) obj;
                if(((String)jsonObj.get(opt)).equals(identifier)){
                    JSONArray existingArray = new JSONArray();
                    for(String s : newList){
                        existingArray.add(s);
                    }


                    jsonObj.put(columnToBeChanged,existingArray);

                }


            }
            FileWriter writer = new FileWriter(file);
            writer.write(array.toJSONString());
            writer.flush();
            writer.close();


        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

    }
    //overWrite the given json file's given column with the new given  integer list
    private void overWriteDataInteger(String opt,String file,String identifier,String columnToBeChanged,ArrayList<Integer> newList){
        JSONParser parser = new JSONParser();
        FileReader reader = null;
        try {
            reader = new FileReader(file);
            JSONArray array = (JSONArray) parser.parse(reader);

            for(Object obj:array){

                JSONObject jsonObj = (JSONObject) obj;
                if(((String)jsonObj.get(opt)).equals(identifier)){
                    JSONArray existingArray = new JSONArray();
                    for(Integer s : newList){
                        existingArray.add(s);
                    }


                    jsonObj.put(columnToBeChanged,existingArray);

                }


            }
            FileWriter writer = new FileWriter(file);
            writer.write(array.toJSONString());
            writer.flush();
            writer.close();


        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

    }



    //for given courses and their corresponding course sections, change the demanded courses and demanded course section column of the students' json file
    public void demandCourses(ArrayList<Course> selectedCourses,Student student,ArrayList<CourseSection> courseSections){

        

        //Change the registration log of the student
        student.getStudentRegistrationLog().setDemandedCourses(selectedCourses,courseSections);
        
        //Change given objects to their string versions
       ArrayList<String> list = new ArrayList<>();
       ArrayList<Integer> list2 = new ArrayList<>();
        for(int i =0;i<selectedCourses.size();i++){

            list2.add(courseSections.get(i).getSectionNumber());
            list.add(selectedCourses.get(i).getCourseCode());
        }

        changeDataString("ID","JSONfiles/students.json",""+student.getID(),"DemandedCourses",list);

        changeDataInteger("ID","JSONfiles/students.json",""+student.getID(),"DemandedCoursesSections",list2);


    }
    //for given courses of the student, remove the given courses from student's registration log and the student's json column.
    public void rejectCourses(Student student,ArrayList<Course> rejectedCourses){

        ArrayList<Course>List1 = student.getStudentRegistrationLog().getDemandedCourses();
        ArrayList<CourseSection>List2 = student.getStudentRegistrationLog().getDemandCoursesSections();
        for(int i=0;i<rejectedCourses.size();i++){
            for(int j=0;j<List1.size();j++){
                if(rejectedCourses.get(i).getCourseCode().equals(List1.get(j).getCourseCode())){
                    List1.remove(j);
                    List2.remove(j);
                }
            }
        }
        ArrayList<String> l = new ArrayList<>();
        ArrayList<Integer> l2 = new ArrayList<>();
        for(int i =0;i<List1.size();i++){


            l.add(List1.get(i).getCourseCode());
            l2.add(List2.get(i).getSectionNumber());
        }



        overWriteDataString("ID","JSONfiles/students.json",""+student.getID(),"DemandedCourses",l);
        overWriteDataInteger("ID","JSONfiles/students.json",""+student.getID(),"DemandedCoursesSections",l2);


    }



    public void approveCourses(Student student,ArrayList<Course> approvedCourses, ArrayList<CourseSection> courseSections){
        student.getStudentRegistrationLog().setCurrentCourses(student.getStudentRegistrationLog().getDemandedCourses(),courseSections);


        ArrayList<String> list = new ArrayList<>();
        ArrayList<Integer> list2 = new ArrayList<>();
        for(int i =0;i<approvedCourses.size();i++){

            list2.add(courseSections.get(i).getSectionNumber());
            list.add(approvedCourses.get(i).getCourseCode());
        }

        changeDataString("ID","JSONfiles/students.json",""+student.getID(),"CurrentCourses",list);

        changeDataInteger("ID","JSONfiles/students.json",""+student.getID(),"CurrentCoursesSections",list2);
        
    

        
    }
    //create the student,student's registration log from the json file.
    public Student createStudent(String userName){
        JSONParser parser = new JSONParser();
        try {
            // Parse the JSON array

            FileReader reader = new FileReader("JSONfiles/students.json");
            JSONArray studentsArray = (JSONArray) parser.parse(reader);
            // Specify the username you want to search for


            // Search for the student
            boolean studentFound = false;
            for (Object obj : studentsArray) {
                JSONObject student = (JSONObject) obj;
                if (((String)student.get("UserName")).equals(userName)) {

                   ArrayList<Course> finished = createCourses((ArrayList<String>) student.get("FinishedCourses"));
                   ArrayList<Course> current = createCourses(( ArrayList<String>) student.get("CurrentCourses"));
                   ArrayList<CourseSection> currSections;
                   if(student.get("CurrentCoursesSections")==null){
                    ArrayList<Integer> ccs = new ArrayList<>();
                    currSections= createSections(current,ccs);
                   }
                  else{
                       ArrayList<Integer> dList = new ArrayList<>();
                       org.json.simple.JSONArray dListArray = (org.json.simple.JSONArray) student.get("CurrentCoursesSections");

                       for (Object obj2 : dListArray) {
                           Long l = (Long) obj2;
                           dList.add(l.intValue());
                       }


                      currSections= createSections(current,dList);
                   }


                   ArrayList<Course> demanded = createCourses((ArrayList<String>) student.get("DemandedCourses"));

                   ArrayList<CourseSection> demSections ;
                   if(student.get("DemandedCoursesSections")==null){
                    ArrayList<Integer> ccs = new ArrayList<>();
                    demSections= createSections(current,ccs);
                   }

                  else{
                       ArrayList<Integer> dList = new ArrayList<>();
                       org.json.simple.JSONArray dListArray = (org.json.simple.JSONArray) student.get("DemandedCoursesSections");

                       for (Object obj2 : dListArray) {
                           Long l = (Long) obj2; // Cast each object to Long
                           dList.add(l.intValue()); // Convert to Integer and add to dList
                       }

                      demSections= createSections(demanded, dList);
                   }

                    StudentRegistrationLog srl = new StudentRegistrationLog(finished,current,demanded);
                    srl.setCurrentCoursesSections(currSections);
                    srl.setDemandedCoursesSections(demSections);

                    

                    Student studentObject = new Student( Integer.parseInt((String)student.get("ID")), (String) student.get("NameSurname"),'s', srl);
                    studentFound = true;
                    return studentObject;

                }
            }

            if (!studentFound) {
                System.out.println("Student with username " + userName + " not found.");
            }

        } catch (ParseException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return null;

    }
    //create an advisor object based on the given username
    public Advisor createAdvisor(String userName){
        JSONParser parser = new JSONParser();

        Advisor advisorObject = null;


        try{
            FileReader reader = new FileReader("JSONfiles/advisors.json");
            JSONArray advisorsArray = (JSONArray) parser.parse(reader);

            boolean advisorFound = false;
            //for every json object
            for(Object obj:advisorsArray){
                JSONObject advisor = (JSONObject)obj;
                //get the column with userName and check if it is equal to given username
                if(((String)advisor.get("userName")).equals(userName)){
                    //after finding the username, create the advisor object with required attributes
                    advisorObject = new Advisor(Integer.parseInt((String)advisor.get("ID")),(String)advisor.get("NameSurname"),'a', (ArrayList<String>) advisor.get("studentsNames"));
                    advisorFound=true;

                }


            }

            if (!advisorFound) {
                System.out.println("Advisor with username " + userName + " not found.");
            }


        }
        catch (FileNotFoundException e){
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return advisorObject;
    }




    public ArrayList<Course> createCourses( ArrayList<String> courseString) {
       ArrayList<Course> list= new ArrayList<>();
        
        for(Course c: this.courses ){
                for (String cs : courseString) {
                    if(cs.equals(c.getCourseCode())){
                        list.add(c);

                    }
                }
        }

        

        

        return list;
        


    }

    //Create corresponding course sections based on the indexes of the given course list
    public ArrayList<CourseSection> createSections( ArrayList<Course> courseList, ArrayList<Integer> sections){
       ArrayList<CourseSection> list2 = new ArrayList<>();

        for(int i =0;i<courseList.size();i++){
            CourseSection sect = courseList.get(i).getSections().get((sections.get(i)-1));
            list2.add(sect);

        }
        return list2;
    }

}  


    










