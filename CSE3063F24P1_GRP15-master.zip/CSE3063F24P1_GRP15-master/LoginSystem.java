import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class LoginSystem {
	private Person currentUser;

	public LoginSystem() {
		super();
		currentUser = null;
	}
	
	
	public boolean login(String username ,String password) {
			RegistrationSystem registrationSystem = UserInterface.getRegistrationSystem();
			JSONParser parser = new JSONParser();
			try {
				FileReader reader = new FileReader("JSONfiles/students.json");
				JSONArray studentsArray = (JSONArray) parser.parse(reader);
	
				for (Object obj : studentsArray) {
					JSONObject studentObj = (JSONObject) obj;
	
					String storedUsername = (String) studentObj.get("UserName");
					String storedPassword = (String) studentObj.get("Password");
	
					if (storedUsername.equals(username) && storedPassword.equals(password)) {
						this.currentUser = registrationSystem.createStudent(username);
						return true;
					}
				}
	
			} catch (FileNotFoundException e) {
				System.err.println("Student file not found.");
			} catch (IOException e) {
				System.err.println("An error occurred while reading the student file.");
			} catch (ParseException e) {
				System.err.println("An error occurred while parsing the student file.");
			}
			try {
				FileReader reader = new FileReader("JSONfiles/advisors.json");
				JSONArray advisorArray = (JSONArray) parser.parse(reader);
	
				for (Object obj : advisorArray) {
					JSONObject advisorObj = (JSONObject) obj;
	
					String storedUsername = (String) advisorObj.get("userName");
					String storedPassword = (String) advisorObj.get("Password");
	
					if (storedUsername.equals(username) && storedPassword.equals(password)) {
						this.currentUser = registrationSystem.createAdvisor(username);
						return true;
					}
				}
	
			} catch (FileNotFoundException e) {
				System.err.println("Advisor file not found.");
			} catch (IOException e) {
				System.err.println("An error occurred while reading the advisor file.");
			} catch (ParseException e) {
				System.err.println("An error occurred while parsing the advisor file.");
			}
			
			return false;
	}
	
	public Person getCurrentUser() {
		return currentUser;
	}

	public void logOut()
	{
		this.currentUser = null;
	}

	
}
