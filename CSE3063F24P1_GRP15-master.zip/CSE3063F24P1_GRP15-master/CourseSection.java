public class CourseSection {
    private String day;
    private String hour;
    private int sectionNumber;

    public CourseSection(String day, String hour, int sectionNumber){
        this.day = day;
        this.hour = hour;
        this.sectionNumber = sectionNumber;
    }

    public String getDay(){
        return day;
    }
    public String getHour(){
        return hour;
    }
    public int getSectionNumber(){
        return sectionNumber;
    }
}
